using System.Collections.Generic;
using System.Threading.Tasks;
using LMS.Api.Model;
using Microsoft.EntityFrameworkCore;

namespace LMS.Api.Repository
{
    public interface IMemberRepository
    {
        Task<IEnumerable<Member>> GetMembersList();
        Task<Member> GetMembersById(int memberId);
        Task<Member> AddMember(Member member);
        Task<Member> UpdateMember(Member member);
        Task<Member> DeleteMember(int memberId);
        
    }
}