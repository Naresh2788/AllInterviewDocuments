using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using LMS.Api.Model;
using LMS.Api.Repository;
namespace LMS.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MemberController: ControllerBase
    {
        private readonly IMemberRepository _memberRepository;

        public MemberController(IMemberRepository memberRepository)
        {
            _memberRepository = memberRepository;
        }

        [Route("GetMembersList")] 
        [HttpGet]
        public async Task<ActionResult> GetMembersList()
        {
            return Ok(await _memberRepository.GetMembersList());
        }

        [Route("AddMember")] 
        [HttpPost]
        public async Task<ActionResult> AddMember(Member member)
        {
            return Ok(await _memberRepository.AddMember(member));
        }
        
        [Route("UpdateMember")] 
        [HttpPut]
        public async Task<ActionResult> UpdateMember(Member member)
        {
            return Ok(await _memberRepository.UpdateMember(member));
        }



        
        [HttpGet("{id}")]
        public async Task<ActionResult> GetMembersById(int id)
        {
            return Ok(await _memberRepository.GetMembersById(id));
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteMember(int id)
        {
            return Ok(await _memberRepository.DeleteMember(id));
        }
        private readonly List<Member> MembersData = new List<Member>();

       
    }
}