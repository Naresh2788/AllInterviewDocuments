import { Component } from '@angular/core';
import { MemberService } from '../Services/member.service';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';

@Component({
  selector: 'app-member',
  standalone: true,
   imports: [RouterLink],
  templateUrl: './member.component.html',
  styleUrl: './member.component.scss'
})
export class MemberComponent {
  

  constructor(private memberService: MemberService, private router: Router, private route: ActivatedRoute) { }

  members: any = [];
  

   ngOnInit() {
     
    this.getMembers();
   }

   
  getMembers() {
    this.memberService.getAll().subscribe(response => {
      this.members = response
    }, error => {
      console.log(error)
    })
  }

  navToEditPage(id: number) {
    this.router.navigate(['/EditMember', id])
  }
}
