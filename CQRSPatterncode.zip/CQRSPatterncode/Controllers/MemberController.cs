using LMS.Api.Command.Members;
using LMS.Api.Model;
using LMS.Api.Queries;
using LMS.Api.Repository;
using LMS.Api.Repository.Interface;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace LMS.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MemberController: ControllerBase
    {
        private readonly IMemberRepository _memberRepository;
        private readonly IMediator mediator;
        public MemberController(IMemberRepository memberRepository, IMediator mediator)
        {
            _memberRepository = memberRepository;
            this.mediator = mediator;
        }

       

        [Route("GetMembersList")]
        [HttpGet]
        public async Task<IEnumerable<Member>> GetMembersListNew()
        {
            var memberDetails = await mediator.Send(new GetMemberListQuery());
            return memberDetails;
        }

      

        [Route("AddMember")]
        [HttpPost]
        public async Task<Member> AddMember(Member memberDetails)
        {
            var memberDetail = await mediator.Send(new CreateMemberCommand(
                memberDetails.MemberName,
                memberDetails.Address,
                memberDetails.Email,
                memberDetails.ContactNo));
            return memberDetail;
        }

       
        [Route("UpdateMember")]
        [HttpPut]
        public async Task<Member> UpdateMember(Member memberDetails)
        {
            var memberDetail = await mediator.Send(new UpdateMemberCommand(
                memberDetails.MemberId,
                memberDetails.MemberName,
                memberDetails.Address,
                memberDetails.Email,
                memberDetails.ContactNo));
            return memberDetail;
        }

       

        [HttpGet("{id}")]
        public async Task<Member> GetMembersById(int id)
        {
            var memberDetails = await mediator.Send(new GetMemberByIdQuery() { Id = id });

            return memberDetails;
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteMember(int id)
        {
            return Ok(await _memberRepository.DeleteMember(id));
        }

       
    }
}