﻿using LMS.Api.Model;
using LMS.Api.Repository.Interface;
using Microsoft.AspNetCore.Mvc;

namespace LMS.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookController : Controller
    {
        private readonly IBookRepository _bookRepository;

        public BookController(IBookRepository bookRepository)
        {
            _bookRepository = bookRepository;
        }

        [Route("GetBooksList")]
        [HttpGet]
        public async Task<ActionResult> GetBooksList()
        {
            return Ok(await _bookRepository.GetBookList());
        }

        [Route("AddBook")]
        [HttpPost]
        public async Task<ActionResult> AddBook(Book book)
        {
            return Ok(await _bookRepository.AddBook(book));
        }

        [Route("UpdateBook")]
        [HttpPut]
        public async Task<ActionResult> UpdateBook(Book book)
        {
            return Ok(await _bookRepository.UpdateBook(book));
        }




        [HttpGet("{id}")]
        public async Task<ActionResult> GetBooksById(int id)
        {
            return Ok(await _bookRepository.GetBookById(id));
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteBook(int id)
        {
            return Ok(await _bookRepository.DeleteBook(id));
        }
       
    }
}
