using System.Collections.Generic;
using System.Threading.Tasks;
using LMS.Api.Model;
using Microsoft.EntityFrameworkCore;

namespace LMS.Api.Repository.Interface
{
    public interface IBookRepository
    {
        Task<IEnumerable<Book>> GetBookList();
        Task<Book> GetBookById(int bookId);
        Task<Book> AddBook(Book member);
        Task<Book> UpdateBook(Book member);
        Task<Book> DeleteBook(int memberId);
        
    }
}