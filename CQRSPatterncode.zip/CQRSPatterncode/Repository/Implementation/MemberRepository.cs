using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using LMS.Api.Model;
using LMS.Api.Repository.Interface;
using Microsoft.EntityFrameworkCore;

namespace LMS.Api.Repository.Implementation
{
    public class MemberRepository:IMemberRepository
    {
         private readonly AppDbContext _appDbContext;
        public MemberRepository(AppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public async Task<Member> AddMember(Member member)
        {
            var result = _appDbContext.Members.Add(member);
            await _appDbContext.SaveChangesAsync();
            return result.Entity;
        }

        public async Task<Member> DeleteMember(int id)
        {
            var member = await _appDbContext.Members.FindAsync(id);
            if (member != null)
            {
                _appDbContext.Members.Remove(member);
                await _appDbContext.SaveChangesAsync();
            }
            return member;
        }

        public async Task<int> DeleteMemberById(int id)
        {
            var member = await _appDbContext.Members.FindAsync(id);
            if (member != null)
            {
                _appDbContext.Members.Remove(member);
                await _appDbContext.SaveChangesAsync();
            }
            return member.MemberId;
        }

        public async Task<Member> UpdateMember(Member member)
        {
            var result = await _appDbContext.Members.FirstOrDefaultAsync(e => e.MemberId == member.MemberId);

            if (result != null)
            {
                result.MemberName = member.MemberName;
                result.Email = member.Email;
                result.ContactNo = member.ContactNo;
                result.Address = member.Address;
                _appDbContext.Members.Update(result);
                await _appDbContext.SaveChangesAsync();
            }
            return result;
        }
        


        public async Task<Member> GetMembersById(int memberId)
        {
            var result = await _appDbContext.Members.FirstOrDefaultAsync(e => e.MemberId == memberId);
            return result;
        }

        public async Task<IEnumerable<Member>> GetMembersList()
        {
            return await _appDbContext.Members.ToListAsync();
        }

       
        
    }
}