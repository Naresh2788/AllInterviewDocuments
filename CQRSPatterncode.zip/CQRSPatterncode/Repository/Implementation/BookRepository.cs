using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using LMS.Api.Model;
using LMS.Api.Repository.Interface;
using Microsoft.EntityFrameworkCore;

namespace LMS.Api.Repository.Implementation
{
    public class BookRepository:IBookRepository
    {
         private readonly AppDbContext _appDbContext;
        public BookRepository(AppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public async Task<Book> AddBook(Book book)
        {
            var result = _appDbContext.Books.Add(book);
            await _appDbContext.SaveChangesAsync();
            return result.Entity;
        }

        public async Task<Book> DeleteBook(int id)
        {
            var member = await _appDbContext.Books.FindAsync(id);
            if (member != null)
            {
                _appDbContext.Books.Remove(member);
                await _appDbContext.SaveChangesAsync();
            }
            return member;
        }

        public async Task<Book> UpdateBook(Book book)
        {
            var result = await _appDbContext.Books.FirstOrDefaultAsync(e => e.BookId == book.BookId);

            if (result != null)
            {
                result.Title = book.Title;
                result.Author = book.Author;
                result.ISBN = book.ISBN;
                result.Edition = book.Edition;
                _appDbContext.Books.Update(result);
                await _appDbContext.SaveChangesAsync();
            }
            return result;
        }
        


        public async Task<Book> GetBookById(int bookId)
        {
            var result = await _appDbContext.Books.FirstOrDefaultAsync(e => e.BookId == bookId);
            return result;
        }

        public async Task<IEnumerable<Book>> GetBookList()
        {
            return await _appDbContext.Books.ToListAsync();
        }

       
        
    }
}