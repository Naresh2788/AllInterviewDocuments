﻿
using LMS.Api.Model;
using LMS.Api.Queries;
using LMS.Api.Repository.Interface;
using MediatR;
using System.Numerics;

namespace LMS.Api.Handlers
{
    public class GetMemberByIdHandler : IRequestHandler<GetMemberByIdQuery, Member>
    {
        private readonly IMemberRepository _memberRepository;

        public GetMemberByIdHandler(IMemberRepository memberRepository)
        {
            _memberRepository = memberRepository;
        }

        public async Task<Member> Handle(GetMemberByIdQuery query, CancellationToken cancellationToken)
        {
            return await _memberRepository.GetMembersById(query.Id);
        }
    }
}
