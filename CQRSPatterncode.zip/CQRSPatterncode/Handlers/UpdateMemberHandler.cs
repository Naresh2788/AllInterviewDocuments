﻿
using LMS.Api.Command.Members;
using LMS.Api.Model;
using LMS.Api.Repository.Interface;
using MediatR;
using System.Net;

namespace CQRSAndMediatRDemo.Handlers
{
    public class UpdateMemberHandler : IRequestHandler<UpdateMemberCommand, Member>
    {
        private readonly IMemberRepository _memberRepository;

        public UpdateMemberHandler(IMemberRepository memberRepository)
        {
            _memberRepository = memberRepository;
        }
        public async Task<Member> Handle(UpdateMemberCommand command, CancellationToken cancellationToken)
        {
            var memberDetails= await _memberRepository.GetMembersById(command.MemberId);
            if (memberDetails == null)
                return default;

            memberDetails.MemberId = command.MemberId;
            memberDetails.MemberName = command.MemberName;
            memberDetails.Address = command.Address;
            memberDetails.Email = command.Email;
            command.ContactNo = command.ContactNo;

            return await _memberRepository.UpdateMember(memberDetails);
        }
    }
}
