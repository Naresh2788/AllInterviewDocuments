﻿
using LMS.Api.Command.Members;
using LMS.Api.Repository.Interface;
using MediatR;

namespace LMS.Api.Handlers
{
    public class DeleteMemberHandler : IRequestHandler<DeleteMemberCommand, int>
    {
        private readonly IMemberRepository _memberRepository;

        public DeleteMemberHandler(IMemberRepository memberRepository)
        {
            _memberRepository = memberRepository;
        }

        public async Task<int> Handle(DeleteMemberCommand command, CancellationToken cancellationToken)
        {
            var memberDetails = await _memberRepository.GetMembersById(command.Id);
            if (memberDetails == null)
                return default;

            return await _memberRepository.DeleteMemberById(memberDetails.MemberId);
        }
    }
}