﻿
using LMS.Api.Command.Members;
using LMS.Api.Model;
using LMS.Api.Repository.Interface;
using MediatR;
using System.Net;
using System.Numerics;

namespace LMS.Api.Handlers
{
    public class CreateMemberHandler: IRequestHandler<CreateMemberCommand, Member>
    {
        private readonly IMemberRepository _memberRepository;

        public CreateMemberHandler(IMemberRepository memberRepository)
        {
            _memberRepository = memberRepository;
        }
        public async Task<Member> Handle(CreateMemberCommand command, CancellationToken cancellationToken)
        {
            var memberDetails = new Member()
            {
                MemberName = command.MemberName,
                Address = command.Address,
                Email = command.Email,
                ContactNo = command.ContactNo
            };

            return await _memberRepository.AddMember(memberDetails);
        }
    }
}
