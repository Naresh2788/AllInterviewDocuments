﻿
using LMS.Api.Model;
using LMS.Api.Queries;
using LMS.Api.Repository.Interface;
using MediatR;
using System.Numerics;

namespace CQRSAndMediatRDemo.Handlers
{
    public class GetMemberListHandler :  IRequestHandler<GetMemberListQuery, IEnumerable<Member>>
    {
        private readonly IMemberRepository _memberRepository;

        public GetMemberListHandler(IMemberRepository memberRepository)
        {
            _memberRepository = memberRepository;
        }

        public async Task<IEnumerable<Member>> Handle(GetMemberListQuery query, CancellationToken cancellationToken)
        {
            return await _memberRepository.GetMembersList();
        }
    }
}
