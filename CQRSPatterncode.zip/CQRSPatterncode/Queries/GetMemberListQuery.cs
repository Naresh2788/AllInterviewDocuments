﻿
using LMS.Api.Model;
using MediatR;

namespace LMS.Api.Queries
{
    public class GetMemberListQuery : IRequest<IEnumerable<Member>>
    {
    }
}
