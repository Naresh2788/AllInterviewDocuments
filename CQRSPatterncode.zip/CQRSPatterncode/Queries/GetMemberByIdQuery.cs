﻿//using CQRSAndMediatRDemo.Models;
using LMS.Api.Model;
using MediatR;

namespace LMS.Api.Queries
{
    public class GetMemberByIdQuery : IRequest<Member>
    {
        public int Id { get; set; }
    }
}
