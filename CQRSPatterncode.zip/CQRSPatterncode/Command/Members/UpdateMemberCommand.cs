﻿using HotChocolate.Types;
using LMS.Api.Model;
using MediatR;

namespace LMS.Api.Command.Members
{
    public class UpdateMemberCommand : IRequest<Member>
    {
        public int MemberId { get; set; }
        public string MemberName { get; set; }
        public string Address { get; set; }
        public string Email { get; set; }
        public string ContactNo { get; set; }

        public UpdateMemberCommand(int id,string memberName, string address, string email, string contactNo)
        {
            MemberId = id;
            MemberName = memberName;
            Address = address;
            Email = email;
            ContactNo = contactNo;
        }
    }
}
