﻿using MediatR;

namespace LMS.Api.Command.Members
{
    public class DeleteMemberCommand : IRequest<int>
    {
        public int Id { get; set; }
    }
}

