﻿
using MediatR;
using System.Numerics;
using LMS.Api.Model;

namespace LMS.Api.Command.Members
{
    public class CreateMemberCommand : IRequest<Member>
    {
        public int MemberId { get; set; }
        public string MemberName { get; set; }
        public string Address { get; set; }
        public string Email { get; set; }
        public string ContactNo { get; set; }

        public CreateMemberCommand(string memberName, string address, string email, string contactNo)
        {
            MemberName = memberName;
            Address = address;
            Email = email;
            ContactNo = contactNo;
        }
    }
}
